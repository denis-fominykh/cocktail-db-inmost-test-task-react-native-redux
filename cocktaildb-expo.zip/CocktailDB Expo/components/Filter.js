import React, { useState, useEffect } from 'react';
import { StyleSheet, View, TouchableOpacity, Text } from 'react-native';
import { CheckBox } from 'react-native-elements';
import { Feather } from '@expo/vector-icons';
import { EvilIcons } from '@expo/vector-icons';

const Filter = ({ category, checked, setCategory }) => {
  const [isChecked, setIsChecked] = useState(checked);

  useEffect(() => {
    setCategory({
      name: category.name,
      id: category.id,
      checked: isChecked,
    });
  }, [isChecked]);

  return (
    <View style={styles.checkboxContainer}>
      <Text style={styles.text}>{category.name}</Text>
      <CheckBox
        iconRight
        checked={isChecked}
        checkedIcon={<Feather name="check" size={35} color="black" />}
        uncheckedIcon={<EvilIcons name="close" size={35} color="white" />}
        onPress={() => setIsChecked((value) => !value)}
        containerStyle={styles.checkbox}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  checkboxContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    height: 65,
    width: '100%',
    paddingHorizontal: 35,
  },
  text: {
    color: '#7E7E7E',
    fontSize: 16,
  },
  checkbox: {
    backgroundColor: '#fff',
    padding: 0,
  },
});

export default Filter;
